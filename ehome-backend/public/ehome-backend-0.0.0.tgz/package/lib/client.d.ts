import type { TransportConnection, Application } from '@feathersjs/feathers';
import type { AuthenticationClientOptions } from '@feathersjs/authentication-client';
import './services/membership/membership.shared';
export type { Membership, MembershipData, MembershipQuery, MembershipPatch } from './services/membership/membership.shared';
import './services/states/states.shared';
export type { State, StateData, StateQuery, StatePatch } from './services/states/states.shared';
import './services/password/password.shared';
export type { Password, PasswordData, PasswordQuery, PasswordPatch } from './services/password/password.shared';
import './services/groups/groups.shared';
export type { Group, GroupData, GroupQuery, GroupPatch } from './services/groups/groups.shared';
import './services/devices/devices.shared';
export type { Device, DeviceData, DeviceQuery, DevicePatch } from './services/devices/devices.shared';
import './services/device-manager/device-manager.shared';
export type { DeviceManager, DeviceManagerData, DeviceManagerQuery, DeviceManagerPatch } from './services/device-manager/device-manager.shared';
import './services/users/users.shared';
export type { User, UserData, UserQuery, UserPatch } from './services/users/users.shared';
export interface Configuration {
    connection: TransportConnection<ServiceTypes>;
}
export interface ServiceTypes {
}
export type ClientApplication = Application<ServiceTypes, Configuration>;
/**
 * Returns a typed client for the ehome-backend app.
 *
 * @param connection The REST or Socket.io Feathers client connection
 * @param authenticationOptions Additional settings for the authentication client
 * @see https://dove.feathersjs.com/api/client.html
 * @returns The Feathers client application
 */
export declare const createClient: <Configuration = any>(connection: TransportConnection<ServiceTypes>, authenticationOptions?: Partial<AuthenticationClientOptions>) => ClientApplication;
