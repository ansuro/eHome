import type { HookContext } from '../declarations';
export declare const findAll: (context: HookContext) => Promise<void>;
