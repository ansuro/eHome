import { HookContext, NextFunction } from '../declarations';
export declare const startMQTTBroker: (context: HookContext, next: NextFunction) => Promise<void>;
export declare const stopMQTTBroker: (context: HookContext, next: NextFunction) => Promise<void>;
