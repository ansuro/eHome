import { HookContext, NextFunction } from "@feathersjs/feathers";
export declare const resetDevices: (context: HookContext, next: NextFunction) => Promise<void>;
