import { HookContext } from '@feathersjs/feathers';
export declare const logPayload: (context: HookContext) => Promise<HookContext<import("@feathersjs/feathers").Application<any, any>, any>>;
