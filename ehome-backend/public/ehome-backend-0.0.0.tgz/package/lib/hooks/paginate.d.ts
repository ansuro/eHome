import type { HookContext } from '../declarations';
export declare const paginate: (context: HookContext) => Promise<void>;
