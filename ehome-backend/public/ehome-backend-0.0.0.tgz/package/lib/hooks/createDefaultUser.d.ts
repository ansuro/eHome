import { HookContext, NextFunction } from "@feathersjs/feathers";
export declare const createDefaultUser: (context: HookContext, next: NextFunction) => Promise<void>;
