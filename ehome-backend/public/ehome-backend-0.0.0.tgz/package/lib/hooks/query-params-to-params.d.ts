import type { HookContext } from '../declarations';
export declare const queryParamsToParams: (context: HookContext) => Promise<void>;
