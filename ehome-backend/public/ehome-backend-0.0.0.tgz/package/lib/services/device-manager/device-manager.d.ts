import type { Application } from '../../declarations';
import { DeviceManagerService } from './device-manager.class';
import { deviceManagerPath } from './device-manager.shared';
export * from './device-manager.class';
export * from './device-manager.schema';
export declare const deviceManager: (app: Application) => void;
declare module '../../declarations' {
    interface ServiceTypes {
        [deviceManagerPath]: DeviceManagerService;
    }
}
