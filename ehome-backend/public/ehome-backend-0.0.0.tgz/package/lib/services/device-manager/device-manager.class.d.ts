import type { Id, NullableId, Params, ServiceInterface } from '@feathersjs/feathers';
import type { Application } from '../../declarations';
import type { DeviceManager, DeviceManagerData, DeviceManagerPatch, DeviceManagerQuery } from './device-manager.schema';
export type { DeviceManager, DeviceManagerData, DeviceManagerPatch, DeviceManagerQuery };
export interface DeviceManagerServiceOptions {
    app: Application;
}
export interface DeviceManagerParams extends Params<DeviceManagerQuery> {
}
export declare class DeviceManagerService<ServiceParams extends DeviceManagerParams = DeviceManagerParams> implements ServiceInterface<DeviceManager, DeviceManagerData, ServiceParams, DeviceManagerPatch> {
    options: DeviceManagerServiceOptions;
    private app;
    private mqtt;
    constructor(options: DeviceManagerServiceOptions);
    mqttSetup(): void;
    connect(mac: string): Promise<void>;
    disconnect(mac: string): Promise<void>;
    find(_params?: ServiceParams): Promise<DeviceManager[]>;
    get(id: Id, _params?: ServiceParams): Promise<DeviceManager>;
    create(data: DeviceManagerData, params?: ServiceParams): Promise<DeviceManager>;
    create(data: DeviceManagerData[], params?: ServiceParams): Promise<DeviceManager[]>;
    update(id: NullableId, data: DeviceManagerData, _params?: ServiceParams): Promise<DeviceManager>;
    patch(id: NullableId, data: DeviceManagerPatch, _params?: ServiceParams): Promise<DeviceManager>;
    remove(id: NullableId, _params?: ServiceParams): Promise<DeviceManager>;
}
export declare const getOptions: (app: Application) => {
    app: Application;
};
