import type { NullableId, Params, ServiceInterface } from '@feathersjs/feathers';
import type { Application } from '../../declarations';
import type { DeviceManager, DeviceManagerData, DeviceManagerPatch, DeviceManagerQuery } from './device-manager.schema';
import type { State } from '../states/states.schema';
export type { DeviceManager, DeviceManagerData, DeviceManagerPatch, DeviceManagerQuery };
export interface DeviceManagerServiceOptions {
    app: Application;
}
export interface DeviceManagerParams extends Params<DeviceManagerQuery> {
}
export declare class DeviceManagerService<ServiceParams extends DeviceManagerParams = DeviceManagerParams> implements ServiceInterface<DeviceManager, DeviceManagerData, ServiceParams, DeviceManagerPatch> {
    options: DeviceManagerServiceOptions;
    private app;
    private mqtt;
    constructor(options: DeviceManagerServiceOptions);
    mqttSend(state: State | State[]): void;
    private _send;
    mqttSetup(): void;
    connect(mac: string): Promise<void>;
    disconnect(mac: string): Promise<void>;
    patch(id: NullableId, data: DeviceManagerPatch, _params?: ServiceParams): Promise<DeviceManager>;
    find(_params?: ServiceParams): Promise<DeviceManager[]>;
}
export declare const getOptions: (app: Application) => {
    app: Application;
    sanitize: boolean;
};
