import type { Params } from '@feathersjs/feathers';
import type { ClientApplication } from '../../client';
import type { DeviceManager, DeviceManagerData, DeviceManagerPatch, DeviceManagerQuery, DeviceManagerService } from './device-manager.class';
export type { DeviceManager, DeviceManagerData, DeviceManagerPatch, DeviceManagerQuery };
export type DeviceManagerClientService = Pick<DeviceManagerService<Params<DeviceManagerQuery>>, (typeof deviceManagerMethods)[number]>;
export declare const deviceManagerPath = "device-manager";
export declare const deviceManagerMethods: readonly ["patch"];
export declare const deviceManagerClient: (client: ClientApplication) => void;
declare module '../../client' {
    interface ServiceTypes {
        [deviceManagerPath]: DeviceManagerClientService;
    }
}
