import type { Application } from '../../declarations';
import { GroupService } from './groups.class';
import { groupPath } from './groups.shared';
export * from './groups.class';
export * from './groups.schema';
export declare const group: (app: Application) => void;
declare module '../../declarations' {
    interface ServiceTypes {
        [groupPath]: GroupService;
    }
}
