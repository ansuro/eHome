import type { Params } from '@feathersjs/feathers';
import type { ClientApplication } from '../../client';
import type { Group, GroupData, GroupPatch, GroupQuery, GroupService } from './groups.class';
export type { Group, GroupData, GroupPatch, GroupQuery };
export type GroupClientService = Pick<GroupService<Params<GroupQuery>>, (typeof groupMethods)[number]>;
export declare const groupPath = "groups";
export declare const groupMethods: readonly ["find", "get", "create", "patch", "remove"];
export declare const groupClient: (client: ClientApplication) => void;
declare module '../../client' {
    interface ServiceTypes {
        [groupPath]: GroupClientService;
    }
}
