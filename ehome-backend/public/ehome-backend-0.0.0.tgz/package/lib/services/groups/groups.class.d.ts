import type { Paginated, Params } from '@feathersjs/feathers';
import { KnexService } from '@feathersjs/knex';
import type { KnexAdapterParams, KnexAdapterOptions } from '@feathersjs/knex';
import type { Application } from '../../declarations';
import type { Group, GroupData, GroupPatch, GroupQuery } from './groups.schema';
export type { Group, GroupData, GroupPatch, GroupQuery };
export interface GroupParams extends KnexAdapterParams<GroupQuery> {
}
export declare class GroupService<ServiceParams extends Params = GroupParams> extends KnexService<Group, GroupData, GroupParams, GroupPatch> {
    find(params?: ServiceParams & {
        paginate: false;
    }): Promise<Group[]>;
    find(params?: ServiceParams & {
        paginate?: {
            default?: number;
            max?: number;
        };
    }): Promise<Paginated<Group>>;
}
export declare const getOptions: (app: Application) => KnexAdapterOptions;
