import type { Params } from '@feathersjs/feathers';
import type { ClientApplication } from '../../client';
import type { State, StateData, StatePatch, StateQuery, StateService } from './states.class';
export type { State, StateData, StatePatch, StateQuery };
export type StateClientService = Pick<StateService<Params<StateQuery>>, (typeof stateMethods)[number]>;
export declare const statePath = "states";
export declare const stateMethods: readonly ["find", "get"];
export declare const stateClient: (client: ClientApplication) => void;
declare module '../../client' {
    interface ServiceTypes {
        [statePath]: StateClientService;
    }
}
