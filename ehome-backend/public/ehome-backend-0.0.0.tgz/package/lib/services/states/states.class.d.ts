import type { Paginated, Params } from '@feathersjs/feathers';
import { KnexService } from '@feathersjs/knex';
import type { KnexAdapterParams, KnexAdapterOptions } from '@feathersjs/knex';
import type { Application } from '../../declarations';
import type { State, StateData, StatePatch, StateQuery } from './states.schema';
export type { State, StateData, StatePatch, StateQuery };
export interface StateParams extends KnexAdapterParams<StateQuery> {
}
export declare class StateService<ServiceParams extends Params = StateParams> extends KnexService<State, StateData, StateParams, StatePatch> {
    find(params?: ServiceParams & {
        paginate: false;
    }): Promise<State[]>;
    find(params?: ServiceParams & {
        paginate?: {
            default?: number;
            max?: number;
        };
    }): Promise<Paginated<State>>;
}
export declare const getOptions: (app: Application) => KnexAdapterOptions;
