import type { Application } from '../../declarations';
import { StateService } from './states.class';
import { statePath } from './states.shared';
export * from './states.class';
export * from './states.schema';
export declare const state: (app: Application) => void;
declare module '../../declarations' {
    interface ServiceTypes {
        [statePath]: StateService;
    }
}
