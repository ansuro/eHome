import type { Application } from '../../declarations';
import { DeviceService } from './devices.class';
import { devicePath } from './devices.shared';
export * from './devices.class';
export * from './devices.schema';
export declare const device: (app: Application) => void;
declare module '../../declarations' {
    interface ServiceTypes {
        [devicePath]: DeviceService;
    }
}
