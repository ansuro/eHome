import type { Id, NullableId, Params, ServiceInterface } from '@feathersjs/feathers';
import type { Application } from '../../declarations';
import type { Password, PasswordData, PasswordPatch, PasswordQuery } from './password.schema';
export type { Password, PasswordData, PasswordPatch, PasswordQuery };
export interface PasswordServiceOptions {
    app: Application;
}
export interface PasswordParams extends Params<PasswordQuery> {
}
export declare class PasswordService<ServiceParams extends PasswordParams = PasswordParams> implements ServiceInterface<Password, PasswordData, ServiceParams, PasswordPatch> {
    options: PasswordServiceOptions;
    constructor(options: PasswordServiceOptions);
    find(_params?: ServiceParams): Promise<Password[]>;
    get(id: Id, _params?: ServiceParams): Promise<Password>;
    create(data: PasswordData, params?: ServiceParams): Promise<Password>;
    create(data: PasswordData[], params?: ServiceParams): Promise<Password[]>;
    update(id: NullableId, data: PasswordData, _params?: ServiceParams): Promise<Password>;
    patch(id: NullableId, data: PasswordPatch, _params?: ServiceParams): Promise<Password>;
    remove(id: NullableId, _params?: ServiceParams): Promise<Password>;
}
export declare const getOptions: (app: Application) => {
    app: Application;
};
