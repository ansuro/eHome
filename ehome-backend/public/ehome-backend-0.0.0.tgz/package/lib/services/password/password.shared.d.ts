import type { Params } from '@feathersjs/feathers';
import type { ClientApplication } from '../../client';
import type { Password, PasswordData, PasswordPatch, PasswordQuery, PasswordService } from './password.class';
export type { Password, PasswordData, PasswordPatch, PasswordQuery };
export type PasswordClientService = Pick<PasswordService<Params<PasswordQuery>>, (typeof passwordMethods)[number]>;
export declare const passwordPath = "password";
export declare const passwordMethods: readonly ["find", "get", "create", "patch", "remove"];
export declare const passwordClient: (client: ClientApplication) => void;
declare module '../../client' {
    interface ServiceTypes {
        [passwordPath]: PasswordClientService;
    }
}
