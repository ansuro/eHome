import type { Application } from '../../declarations';
import { PasswordService } from './password.class';
import { passwordPath } from './password.shared';
export * from './password.class';
export * from './password.schema';
export declare const password: (app: Application) => void;
declare module '../../declarations' {
    interface ServiceTypes {
        [passwordPath]: PasswordService;
    }
}
