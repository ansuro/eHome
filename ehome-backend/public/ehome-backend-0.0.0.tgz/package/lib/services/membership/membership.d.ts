import type { Application } from '../../declarations';
import { MembershipService } from './membership.class';
import { membershipPath } from './membership.shared';
export * from './membership.class';
export * from './membership.schema';
export declare const membership: (app: Application) => void;
declare module '../../declarations' {
    interface ServiceTypes {
        [membershipPath]: MembershipService;
    }
}
