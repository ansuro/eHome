import type { Paginated, Params } from '@feathersjs/feathers';
import { KnexService } from '@feathersjs/knex';
import type { KnexAdapterParams, KnexAdapterOptions } from '@feathersjs/knex';
import type { Application } from '../../declarations';
import type { Membership, MembershipData, MembershipPatch, MembershipQuery } from './membership.schema';
export type { Membership, MembershipData, MembershipPatch, MembershipQuery };
export interface MembershipParams extends KnexAdapterParams<MembershipQuery> {
}
export declare class MembershipService<ServiceParams extends Params = MembershipParams> extends KnexService<Membership, MembershipData, MembershipParams, MembershipPatch> {
    find(params?: ServiceParams & {
        paginate: false;
    }): Promise<Membership[]>;
    find(params?: ServiceParams & {
        paginate?: {
            default?: number;
            max?: number;
        };
    }): Promise<Paginated<Membership>>;
}
export declare const getOptions: (app: Application) => KnexAdapterOptions;
