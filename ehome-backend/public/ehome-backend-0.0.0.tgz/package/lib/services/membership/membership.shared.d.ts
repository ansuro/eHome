import type { Params } from '@feathersjs/feathers';
import type { ClientApplication } from '../../client';
import type { Membership, MembershipData, MembershipPatch, MembershipQuery, MembershipService } from './membership.class';
export type { Membership, MembershipData, MembershipPatch, MembershipQuery };
export type MembershipClientService = Pick<MembershipService<Params<MembershipQuery>>, (typeof membershipMethods)[number]>;
export declare const membershipPath = "membership";
export declare const membershipMethods: readonly ["find", "get", "create", "patch", "remove"];
export declare const membershipClient: (client: ClientApplication) => void;
declare module '../../client' {
    interface ServiceTypes {
        [membershipPath]: MembershipClientService;
    }
}
